package mhhwte02;

import javax.swing.*;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class Window extends Launcher {

    private final int size;
    private final int blackhole;
    private int redshipid;
    private int blueshipid;
    private String text;
    private boolean hasyellow;
    private int x;
    private int y;
    private final JLabel label;
    private final JLabel gamestatus;
    private final JButton[][] boardbuttons;
    private final Gamelogic gamelogic;
    private final LauncherModel mainWindow;

    public Window(int size, LauncherModel mainWindow) {
        this.size = size;
        blackhole = size / 2;
        redshipid = 1;
        blueshipid = 1;
        hasyellow = false;
        x = size;
        y = size;
        text = null;
        boardbuttons = new JButton[size][size];
        this.mainWindow = mainWindow;
        mainWindow.getWindowList().add(this);
        gamelogic = new Gamelogic(size);
        JMenuBar menuBar = new JMenuBar();
        JMenu menuFile = new JMenu("Game");
        JMenuItem newGame = new JMenuItem(new AbstractAction("New Game") {
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        });
        JMenuItem change = new JMenuItem(new AbstractAction("Change boardsize") {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                mainWindow.setVisible(true);
            }
        });
        JMenuItem menuExit = new JMenuItem(new AbstractAction("Exit") {
            @Override
            public void actionPerformed(ActionEvent e) {
                showExitConfirmation();
            }
        });
        menuFile.add(newGame);
        menuFile.addSeparator();
        menuFile.add(change);
        menuFile.addSeparator();
        menuFile.add(menuExit);
        menuBar.add(menuFile);
        setJMenuBar(menuBar);
        JPanel top = new JPanel();
        gamestatus = new JLabel("");
        updateGameStatus();
        top.add(gamestatus);
        JPanel bottom = new JPanel();
        label = new JLabel("Move ship to direction:");
        bottom.add(label);
        JButton up = new JButton("Up");
        up.addActionListener(directionActionListener("up"));
        JButton down = new JButton("Down");
        down.addActionListener(directionActionListener("down"));
        JButton left = new JButton("Left");
        left.addActionListener(directionActionListener("left"));
        JButton right = new JButton("Right");
        right.addActionListener(directionActionListener("right"));
        bottom.add(up);
        bottom.add(down);
        bottom.add(left);
        bottom.add(right);
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(size, size));
        for (int i = 0; i < size; ++i) {
            for (int j = 0; j < size; ++j) {
                addButton(mainPanel, i, j);
            }
        }
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(top, BorderLayout.PAGE_START);
        getContentPane().add(mainPanel, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.AFTER_LAST_LINE);
    }

    /**
     * Létrehozza a gombokhoz az eseményfigyelőt kattintáshoz.
     * Színezi a mező elemeit a lépséhez emgfelelő színre, a kiválaszott karaktert sárgára színezi, 
     * illetve gondoksodik arról, hogy egyszerre csak egy mező lehessen sárga.
     * Fekete lyukra lépés esetén eltűnteti a karaktert.
     * @param panel aktális tábla amin dolgozik.
     * @param i tábla vízszintes értéke
     * @param j tábla függőleges értéke
     */
    private void addButton(JPanel panel, final int i, final int j) {
        boardbuttons[i][j] = new JButton();
        boardbuttons[i][j].addActionListener((ActionEvent e) -> {
            if (!hasyellow && gamelogic.getTable(i, j) == gamelogic.getActualPlayer()) {
                boardbuttons[i][j].setBackground(Color.YELLOW);
                hasyellow = !hasyellow;
                x = i;
                y = j;
                text = boardbuttons[i][j].getText();
            } else if (hasyellow && gamelogic.getTable(i, j) == gamelogic.getActualPlayer()) {
                for (int k = 0; k < size; k++) {
                    for (int l = 0; l < size; l++) {
                        if (boardbuttons[k][l].getBackground() == Color.YELLOW) {
                            boardbuttons[k][l].setBackground((gamelogic.getTable(i, j) == Board.Red) ? Color.RED : Color.BLUE);
                        }
                    }
                    hasyellow = !hasyellow;
                }
                boardbuttons[i][j].setBackground(Color.YELLOW);
                hasyellow = !hasyellow;
                x = i;
                y = j;
                text = boardbuttons[i][j].getText();
            }
        });
        if (i == blackhole && j == blackhole) {
            boardbuttons[i][j].setBackground(Color.BLACK);
        } else if (gamelogic.getTable(i, j) == Board.Red) {
            boardbuttons[i][j].setBackground(Color.RED);
            boardbuttons[i][j].setText(Integer.toString(redshipid));
            redshipid++;
        } else if (gamelogic.getTable(i, j) == Board.Blue) {
            boardbuttons[i][j].setBackground(Color.BLUE);
            boardbuttons[i][j].setText(Integer.toString(blueshipid));
            blueshipid++;

        } else {
            boardbuttons[i][j].setBackground(Color.WHITE);
        }
        panel.add(boardbuttons[i][j]);
    }

    /**
     * Az akutális irányba lépteti a karaktert a táblán, közben ellenrőzi érinti e a feketelyukat. 
     * Ha igen, meghívja a karakterek számát csökkentő függvényt és eltűneti a karaktert,
     * a mezők értékét frissíti. A kijelölt karakter színét sárgára színezi, 
     * illetve gondoskodik arról, hogy egyszerre csak 1 karakter lehessen kiválasztva
     * Fekete lyuk érintése esetén meghívja a karakterek számát csökkentő függvényt, ellenőrzi vége van-e a játéknak,
     * ha igen, meghívja a játék végét jelző függvényt és automatikusan új játékot kezd.
     * @param getdirection akutális irány
     * @return 
     */
    private ActionListener directionActionListener(String getdirection) {
        return (ActionEvent e) -> {
            if (hasyellow && x != size && y != size) {
                int[] result;
                result = gamelogic.move(x, y, getdirection);
                int cx = result[0];
                int cy = result[1];
                hasyellow = !hasyellow;
                boardbuttons[x][y].setBackground(Color.WHITE);
                boardbuttons[x][y].setText(null);
                if (gamelogic.getTable(result[0], result[1]) != Board.Blackhole) {
                    boardbuttons[cx][cy].setBackground((gamelogic.getActualPlayer() == Board.Red) ? Color.RED : Color.BLUE);
                    boardbuttons[cx][cy].setText(text);
                }
                if (gamelogic.getActualPlayer() == Board.Red) {
                    gamelogic.setActualPlayer(Board.Blue);
                } else {
                    gamelogic.setActualPlayer(Board.Red);
                }
                updateGameStatus();
                if (gamelogic.getBlueships() == (size-1)/2) {
                    showGameOverMessage(Board.Blue);
                } else if (gamelogic.getRedships() == (size-1)/2) {
                    showGameOverMessage(Board.Red);
                }
                x = size;
                y = size;
                text = null;
            }
        };
    }
    
    /**
     * Kilépés megerősítés felugró ablak.
     * Igen esetén meghívja az alkalmazást bezáró függvényt.
     */
    private void showExitConfirmation() {
        int exit = JOptionPane.showConfirmDialog(this, "Are you sure, you want to quit?",
                "Exit", JOptionPane.YES_NO_OPTION);
        if (exit == JOptionPane.YES_OPTION) {
            doUponExit();
        }
    }

    /**
     * játék vége esetén kiírja az aktuális nyertest felugró ablakban.
     * @param winner akutális nyertes
     */
    public void showGameOverMessage(Board winner) {
        JOptionPane.showMessageDialog(this,
                "Game over. The winner is: " + winner);
        newGame();
    }

    /**
     * új játékot kezd azonos táblamérettel.
     */
    private void newGame() {
        Window newWindow = new Window(size, mainWindow);
                    switch (size) {
                case 5 -> {
                    newWindow.setSize(500, 400);
                    newWindow.setLocationRelativeTo(null);
                }
                case 7 -> {
                    newWindow.setSize(700,500);
                    newWindow.setLocationRelativeTo(null);
                }
                default -> {
                    newWindow.setSize(900,600);
                    newWindow.setLocationRelativeTo(null);
                }
            }
        newWindow.setVisible(true);
        this.dispose();
        mainWindow.getWindowList().remove(this);
    }

    /**
     * Frissíti a játék aktuális állását tartalmazó labelt.
     */
    private void updateGameStatus() {
        gamestatus.setText("Current player: "
                + gamelogic.getActualPlayer().name() + "  |  "
                + "Ships left:  Red(" + gamelogic.getRedships()
                + ")  -  Blue(" + gamelogic.getBlueships() + ")");
    }

    /**
     * Bezárja az alkalmazást.
     */
    @Override
    protected void doUponExit() {
        super.doUponExit();
        mainWindow.getWindowList().remove(this);
    }

    public JButton[][] getBoardbuttons() {
        return boardbuttons;
    }

    public void setBoardbutton(int i, int j, Board color, String id) {
        this.boardbuttons[i][j].setBackground((color == Board.Red) ? Color.RED : Color.BLUE);
        this.boardbuttons[i][j].setText(id);
    }
}
