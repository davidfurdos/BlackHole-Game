package mhhwte02;

/**
 * A mezők illetbe hajók színei.
 * @author dfurd
 */
public enum Board {
    Blue, Red, White, Blackhole
}
