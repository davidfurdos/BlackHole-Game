package mhhwte02;

public class MHHWTE02 {

    public static void main(String[] args) {
        LauncherModel mainWindow = new LauncherModel();
        mainWindow.setVisible(true);
    }

}
